-- Run this in Supabase Dashboard -> SQL Editor.
create table if not exists public.game_saves (
  user_id uuid not null references auth.users(id) on delete cascade,
  game_id text not null check (game_id in ('game-hub','aquasub-go','jet-rush','fluxr','dustline','hushmarrow')),
  save_data jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, game_id)
);
alter table public.game_saves enable row level security;
drop policy if exists "Players can read their own saves" on public.game_saves;
create policy "Players can read their own saves" on public.game_saves for select to authenticated using (auth.uid() = user_id);
drop policy if exists "Players can create their own saves" on public.game_saves;
create policy "Players can create their own saves" on public.game_saves for insert to authenticated with check (auth.uid() = user_id);
drop policy if exists "Players can update their own saves" on public.game_saves;
create policy "Players can update their own saves" on public.game_saves for update to authenticated using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- Allow the newest game id too (safe to re-run).
alter table public.game_saves drop constraint if exists game_saves_game_id_check;
alter table public.game_saves add constraint game_saves_game_id_check check (game_id in ('game-hub','aquasub-go','jet-rush','fluxr','dustline','hushmarrow','the-hum-below'));

-- PROFILE PICTURES: public "avatars" bucket; each player can only write inside their own folder (<user id>/avatar.jpg).
insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true) on conflict (id) do update set public = true;
drop policy if exists "Avatars are publicly readable" on storage.objects;
create policy "Avatars are publicly readable" on storage.objects for select using (bucket_id = 'avatars');
drop policy if exists "Players can upload their own avatar" on storage.objects;
create policy "Players can upload their own avatar" on storage.objects for insert to authenticated with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Players can replace their own avatar" on storage.objects;
create policy "Players can replace their own avatar" on storage.objects for update to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text) with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "Players can delete their own avatar" on storage.objects;
create policy "Players can delete their own avatar" on storage.objects for delete to authenticated using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);
