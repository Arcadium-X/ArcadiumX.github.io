// Supabase project URL and publishable/anon key. Never put a service_role key here.
window.GAMEHUB_SUPABASE_URL = 'https://kyehbderdpyjudttsgft.supabase.co';
window.GAMEHUB_SUPABASE_ANON_KEY = 'sb_publishable_Fp70J1HD6Rb92_2MgOrOOA_MnxUnNP1';
