ARCADIUMX — NETLIFY DRAG-AND-DROP SITE

Upload the CONTENTS of this folder to your existing Netlify site (Deploys -> drag and drop). Do not upload a parent folder or a ZIP.
Root contains: index.html, cloud-config.js, cloud-save.js, assets/, game/, games/.
cloud-config.js is already filled in with your Supabase URL and publishable key.
Run supabase-schema.sql in the Supabase SQL Editor once (see SETUP-CLOUD-ACCOUNTS.txt).

Games: Aquasub Go, Gloop Royale, Jet Rush, FLUXR, Dustline, Hushmarrow 3D, The Hum Below, Springpeak, Cinderlow.

Performance: Jet Rush, FLUXR and Hushmarrow 3D automatically lower their graphics (resolution, shadows, glow, bump detail, extra lights) when a PC runs them slowly, and raise them again when it is safe. Players can also pick Auto / Low / Medium / High with the small "Graphics" button at the bottom of the screen (bottom-left in Jet Rush and FLUXR, bottom-center in Hushmarrow). The choice is remembered in the browser.

Home page: hovering a game card (on devices with a mouse) plays a short animated preview of that game with a one-line description. Touch screens skip it.

Game of the Week: a spotlight above the game list shows either The Hum Below or Cinderlow, and it switches every Monday (00:00 UTC) automatically. The matching card also gets a gold "Game of the Week" tag. To change which games rotate, edit the LIST near the bottom of index.html.
